﻿using UnityEngine;
using System.Collections;

public class Porta2 : MonoBehaviour {

	public SpriteRenderer door;
	public Sprite doorClose;
	public Sprite doorOpen;
	private bool opened;
	public float openTime;
	private float t1;


	// Use this for initialization
	void Start () {
		t1 = Time.time;
	}
	
	// Update is called once per frame
	void Update () {
		if (Input.GetKey(KeyCode.O) && Time.time - t1 > openTime) {
			opened = !opened;
			t1 = Time.time;
		}
		door.sprite = opened ? doorOpen : doorClose;
	}
}
