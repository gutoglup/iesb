﻿using UnityEngine;
using System.Collections;

public class Porta : MonoBehaviour {

	public SpriteRenderer door;
	private bool opened = false;
	private Color doorColor;

	// Use this for initialization
	void Start () {
		doorColor = door.color;
	}
	
	// Update is called once per frame
	void Update () {
		if(Input.GetKey(KeyCode.O) && !opened) {
			doorColor.a = 0.0f;
			door.color = doorColor;
			opened = true;
			Debug.Log("Aberto");
		} else if (Input.GetKey(KeyCode.C) && opened) {
			doorColor.a = 1.0f;
			door.color = doorColor;
			opened = false;
			Debug.Log("Fechado");
		}
	}
}
