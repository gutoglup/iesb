﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace TwitterService.Models
{
    public class Post
    {
        public int Id_post { get; set; }
        public string Title { get; set; }
        public string Description { get; set; }
        public DateTime Created_date { get; set; }
        public int Id_user { get; set; }

        public Post(int Id_post, string Title, string Description, DateTime Created_date, int Id_user){
            this.Id_post = Id_post;
            this.Title = Title;
            this.Description = Description;
            this.Created_date = Created_date;
            this.Id_user = Id_user;
        }

        public Post( string Title, string Description, DateTime Created_date, int Id_user)
        {
            
            this.Title = Title;
            this.Description = Description;
            this.Created_date = Created_date;
            this.Id_user = Id_user;
        }

        public Post() {
            
        }
    }
}
