﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace TwitterService.Models
{

    public class User
    {
        public string Id_user { get; set; }
        public string Name { get; set; }
        public string Email { get; set; }
        public int Is_active{ get; set; }
        //public List<Posts> Posts { get; set; }
        public User(string Id_user, string Name, string Email, int Is_active)
        {
            this.Id_user = Id_user;
            this.Name = Name;
            this.Email = Email;
            this.Is_active = Is_active;
        }
    }
}
