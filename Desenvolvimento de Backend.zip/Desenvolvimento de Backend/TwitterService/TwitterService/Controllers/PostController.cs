﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using MySql.Data.MySqlClient;
using TwitterService.Models;

namespace TwitterService.Controllers
{
    [Route("api/[controller]")]
    public class PostController : Controller
    {
        // GET api/post
        /// <summary>
        /// Retorna a lista de posts
        /// </summary>
        /// <response code="200">Post criado</response>
        /// <response code="500">Erro interno no servidor</response>
        [HttpGet]
        public List<Post> Get()
        {
            MySqlConnection conexao = new MySqlConnection("server=localhost;port=3306;database=user;user=root;password=gustocnr23");
            MySqlCommand comando = new MySqlCommand("SELECT * FROM posts", conexao);
            MySqlDataReader result;
            List<Post> posts = new List<Post>();
            try
            {
                conexao.Open();
            }
            catch
            {
                return posts;
            }
            result = comando.ExecuteReader();

            while (result.Read())
            {
                posts.Add(new Post(Convert.ToInt32(result["id_user"].ToString()),
                                   result["title"].ToString(),
                                   result["description"].ToString(),
                                   Convert.ToDateTime(result["created_date"].ToString()),
                                   Convert.ToInt32(result["id_user"].ToString())));

            }
            conexao.Close();
            return posts;
        }

        // GET api/post/5
        /// <summary>
        /// Retorna um post através de um ID
        /// </summary>
        /// <response code="200">Post recuperado</response>
        /// <response code="500">Erro interno no servidor</response>
        [HttpGet("{id}")]
        public Post Get(int id)
        {
            MySqlConnection conexao = new MySqlConnection("server=localhost;port=3306;database=user;user=root;password=gustocnr23");
            MySqlCommand comando = new MySqlCommand("SELECT * FROM posts WHERE id_post = @id", conexao);
            comando.Parameters.AddWithValue("@id", id);
            Post post = new Post();
            try {
                conexao.Open();
            } catch {
                return post;
            }
            MySqlDataReader result = comando.ExecuteReader();
            result.Read();
            post = new Post(Convert.ToInt32(result["id_post"].ToString()),
                        result["title"].ToString(),
                        result["description"].ToString(),
                        Convert.ToDateTime(result["created_date"].ToString()),
                        Convert.ToInt32(result["id_user"].ToString()));
            conexao.Close();
            return post;
        }

        // POST api/post
        /// <summary>
        /// Cadastra um Post
        /// </summary>
        /// <response code="200">Post cadastrado</response>
        /// <response code="500">Erro interno no servidor</response>
        [HttpPost]
        public IActionResult Post([FromBody]Post post)
        {
            try
            {
                MySqlConnection conexao = new MySqlConnection("server=localhost;port=3306;database=user;user=root;password=gustocnr23");
                conexao.Open();
                MySqlCommand comando = new MySqlCommand("INSERT INTO posts(title, description, created_date, id_user) VALUES(@title, @description, @created_date, @id_user)", conexao);
                comando.Parameters.AddWithValue("@title", post.Title);
                comando.Parameters.AddWithValue("@description", post.Description);
                comando.Parameters.AddWithValue("@created_date", post.Created_date);
                comando.Parameters.AddWithValue("@id_user", post.Id_user);

                comando.ExecuteNonQuery();
                conexao.Close();
            } catch (MySqlException ex){
                System.Console.WriteLine("Errou: " + ex);
                return StatusCode(500);
            }
            return new ObjectResult(post);
            
        }

        // PUT api/post/5
        /// <summary>
        /// Atualiza um Post específico
        /// </summary>
        /// <response code="200">Post atualizado</response>
        /// <response code="500">Erro interno no servidor</response>
        [HttpPut("{id}")]
        public IActionResult Put(int id, [FromBody]Post post)
        {
            try
            {
                MySqlConnection conexao = new MySqlConnection("server=localhost;port=3306;database=user;user=root;password=gustocnr23");
                conexao.Open();
                MySqlCommand comando = new MySqlCommand("UPDATE posts SET title = @title, description = @description, created_date = @created_date, id_user = @id_user WHERE id_post = @id_post", conexao);
                comando.Parameters.AddWithValue("@id_post", id);
                comando.Parameters.AddWithValue("@title", post.Title);
                comando.Parameters.AddWithValue("@description", post.Description);
                comando.Parameters.AddWithValue("@created_date", post.Created_date);
                comando.Parameters.AddWithValue("@id_user", post.Id_user);

                comando.ExecuteNonQuery();
                conexao.Close();
            }
            catch (MySqlException ex)
            {
                System.Console.WriteLine("Errou: " + ex);
                return StatusCode(500);
            }

            return new ObjectResult(post);
        }

        // DELETE api/post/5
        /// <summary>
        /// Deleta um Post específico
        /// </summary>
        /// <response code="200">Post deletado</response>
        /// <response code="500">Erro interno no servidor</response>
        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            try
            {
                MySqlConnection conexao = new MySqlConnection("server=localhost;port=3306;database=user;user=root;password=gustocnr23");
                conexao.Open();
                MySqlCommand comando = new MySqlCommand("DELETE FROM posts WHERE id_post = @id_post", conexao);
                comando.Parameters.AddWithValue("@id_post", id);

                comando.ExecuteNonQuery();
                conexao.Close();
                return Ok();
            }
            catch
            {
                return StatusCode(500);
            }
        }

    }
}
