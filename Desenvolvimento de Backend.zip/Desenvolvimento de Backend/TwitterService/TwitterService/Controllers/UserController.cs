﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using MySql.Data.MySqlClient;
using TwitterService.Models;

namespace TwitterService.Controllers
{
    [Route("api/[controller]")]
    public class UserController : Controller
    {

        // GET api/user
        /// <summary>
        /// Retorna a lista de usuários
        /// </summary>
        /// <response code="200">Usuário criado</response>
        /// <response code="500">Erro interno no servidor</response>
        [HttpGet]
        public List<User> Get()
        {
            List<User> userList = new List<User>();
            MySqlConnection conexao = new MySqlConnection("server=localhost;port=3306;database=user;user=root;password=Admin12345");
            MySqlCommand comando = new MySqlCommand("SELECT * FROM users", conexao);
            MySqlDataReader result;

            try{
                conexao.Open();
            }
            catch
            {
                return userList;
            }
            result = comando.ExecuteReader();
            while (result.Read())
            {
                userList.Add(new User(result["id_user"].ToString(), 
                                      result["name"].ToString(), 
                                      result["email"].ToString(), 
                                      Convert.ToInt32(result["is_active"].ToString())));
                
            }
            return userList;
        }

        // GET api/user/5
        /// <summary>
        /// Retorna um usuário através de um ID
        /// </summary>
        /// <response code="200">Usuário recuperado</response>
        /// <response code="500">Erro interno no servidor</response>
        [HttpGet("{id}")]
        public List<User> Get(int id)
        {
            List<User> userList = new List<User>();
            MySqlConnection conexao = new MySqlConnection("server=localhost;port=3306;database=user;user=root;password=Admin12345");
            MySqlCommand query = new MySqlCommand("SELECT * FROM users Where id_user = @id_user", conexao);
            query.Parameters.AddWithValue("@id_user", id);
            MySqlDataReader result;

            try
            {
                conexao.Open();
                result = query.ExecuteReader();
            }
            catch
            {
                return userList;
            }
            
            while (result.Read())
            {

                userList.Add(new User(result["id_user"].ToString(),
                                      result["name"].ToString(),
                                      result["email"].ToString(),
                                      Convert.ToInt32(result["is_active"].ToString())));

            }
            return userList;
        }

        // POST api/user
        /// <summary>
        /// Cadastra um Usuário
        /// </summary>
        /// <response code="200">Usuário cadastrado</response>
        /// <response code="500">Erro interno no servidor</response>
        [HttpPost]
        public IActionResult Post([FromBody] User usuario)
        {
            try
            {
                MySqlConnection conexao = new MySqlConnection("server=localhost;port=3306;database=user;user=root;password=Admin12345");
                conexao.Open();
                MySqlCommand comm = conexao.CreateCommand();
                comm.CommandText = "INSERT INTO users(name, email, is_active) VALUES(@name, @email, @is_active)";
                comm.Parameters.AddWithValue("@name", usuario.Name.ToString());
                comm.Parameters.AddWithValue("@email", usuario.Email.ToString());
                comm.Parameters.AddWithValue("@is_active", usuario.Is_active.ToString());
                comm.ExecuteNonQuery();
                conexao.Close();
            } catch {
                return StatusCode(500);
            }
            return new ObjectResult(usuario);
        }

        // PUT api/user/5
        /// <summary>
        /// Atualiza um Usuário específico
        /// </summary>
        /// <response code="200">Usuário atualizado</response>
        /// <response code="500">Erro interno no servidor</response>
        [HttpPut("{id}")]
        public IActionResult Put(int id, [FromBody]User usuario)
        {
            try
            {
                MySqlConnection conexao = new MySqlConnection("server=localhost;port=3306;database=user;user=root;password=Admin12345");
                conexao.Open();
                MySqlCommand comm = conexao.CreateCommand();
                comm.CommandText = "UPDATE users SET name = @name, email = @email , is_active = @is_active WHERE id_user = @id_user";
                comm.Parameters.AddWithValue("@id_user", id);
                comm.Parameters.AddWithValue("@name", usuario.Name.ToString());
                comm.Parameters.AddWithValue("@email", usuario.Email.ToString());
                comm.Parameters.AddWithValue("@is_active", usuario.Is_active.ToString());
                comm.ExecuteNonQuery();
                conexao.Close();
            }
            catch
            {
                return StatusCode(500);
            }
            return new ObjectResult(usuario);
        }

        // DELETE api/user/5
        /// <summary>
        /// Deleta um Usuário específico
        /// </summary>
        /// <response code="200">Usuário deletado</response>
        /// <response code="500">Erro interno no servidor</response>
        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            try
            {
                MySqlConnection conexao = new MySqlConnection("server=localhost;port=3306;database=user;user=root;password=Admin12345");
                conexao.Open();
                MySqlCommand comm = conexao.CreateCommand();
                comm.CommandText = "DELETE FROM users WHERE id_user = @id_user";
                comm.Parameters.AddWithValue("@id_user", id);
                comm.ExecuteNonQuery();
                conexao.Close();
                return Ok();
            }
            catch
            {
                return StatusCode(500);
            }
        }
    }
}
