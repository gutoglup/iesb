namespace TodoWebServices.Models
{
    public class Task
    {
        public string ID { get; set; }
        public string Name { get; set; }
        public bool IsCompleted{ get; set; }
    }
}