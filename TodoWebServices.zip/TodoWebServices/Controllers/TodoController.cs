using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.AspNetCore.Mvc;
using TodoWebServices.Models;

namespace TodoWebServices.Controllers
{
    [Route("api/[controller]")]
    public class TodoController : Controller
    {

        private static List<Task> tasksList = new List<Task>();

        [HttpGet]
        public IEnumerable<Task> GetTasks()
        {
            return tasksList;
        }

        [HttpPost]
        public IActionResult InsertTask([FromBody] Task task) {
            if (task == null) {
                return BadRequest();
            }
            task.ID = new Random().Next(1, 10000).ToString();
            tasksList.Add(task);
            //return new ObjectResult(task);
            return CreatedAtRoute("GetTask", new { id = task.ID }, task);
        }

        [HttpGet("{id}", Name = "GetTask")]
        public IActionResult GetTask(string id) 
        {
            var item = tasksList.FirstOrDefault( t => t.ID == id);
            if (item == null) return NotFound();

            return new ObjectResult(item);
        }

        [HttpPut("{id}")]
        public IActionResult UpdateTask(string id, [FromBody] Task task) {
            if (task == null) BadRequest();

            var item = tasksList.FirstOrDefault( t => t.ID == id);
            if (item == null) return NotFound();

            item.Name = task.Name;
            item.IsCompleted = task.IsCompleted;

            return new ObjectResult(item);
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteTask(string id) {
            var item = tasksList.FirstOrDefault(t => t.ID == id);
            if (item == null) return NotFound();
            tasksList.Remove(item);
            return Ok();
        }
    }

}